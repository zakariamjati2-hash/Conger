import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

// DELETE - Supprimer un utilisateur (Admin seulement)
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Accès non autorisé' }, { status: 403 });
    }

    const userId = id;

    // Ne pas permettre de supprimer son propre compte
    if (userId === session.user.id) {
      return NextResponse.json({ error: 'Vous ne pouvez pas supprimer votre propre compte' }, { status: 400 });
    }

    // Vérifier si l'utilisateur existe
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        _count: {
          select: {
            projectsOwned: true,
            projectAssignments: true,
            tasks: true,
          }
        }
      }
    });

    if (!user) {
      return NextResponse.json({ error: 'Utilisateur introuvable' }, { status: 404 });
    }

    // Vérifier si l'utilisateur a des projets ou tâches en cours
    if (user._count.projectsOwned > 0 || user._count.tasks > 0) {
      return NextResponse.json({ 
        error: 'Impossible de supprimer cet utilisateur car il a des projets ou tâches en cours. Désactivez-le plutôt.' 
      }, { status: 400 });
    }

    // Supprimer les assignations de projets d'abord
    await prisma.projectAssignment.deleteMany({
      where: { userId }
    });

    // Supprimer les logs d'audit
    await prisma.auditLog.deleteMany({
      where: { userId }
    });

    // Supprimer l'utilisateur
    await prisma.user.delete({
      where: { id: userId }
    });

    // Log d'audit pour la suppression
    await prisma.auditLog.create({
      data: {
        userId: session.user.id!,
        entity: 'User',
        entityId: userId,
        action: 'DELETE',
        details: {
          deletedUser: user.email,
          deletedUserName: user.name,
          role: user.role,
          deletedBy: session.user.email
        }
      }
    });

    return NextResponse.json({ 
      message: 'Utilisateur supprimé avec succès',
      deletedUser: {
        id: user.id,
        email: user.email,
        name: user.name
      }
    });
  } catch (error) {
    console.error('Error deleting user:', error);
    return NextResponse.json({ error: 'Erreur lors de la suppression de l\'utilisateur' }, { status: 500 });
  }
}

// PATCH - Modifier un utilisateur (Admin seulement)
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Accès non autorisé' }, { status: 403 });
    }

    const userId = id;
    const body = await request.json();

    // Vérifier si l'utilisateur existe
    const existingUser = await prisma.user.findUnique({
      where: { id: userId }
    });

    if (!existingUser) {
      return NextResponse.json({ error: 'Utilisateur introuvable' }, { status: 404 });
    }

    // Mettre à jour l'utilisateur
    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: {
        ...(body.name && { name: body.name }),
        ...(body.role && { role: body.role }),
        ...(typeof body.isActive === 'boolean' && { isActive: body.isActive }),
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        updatedAt: true,
      }
    });

    // Log d'audit
    await prisma.auditLog.create({
      data: {
        userId: session.user.id!,
        entity: 'User',
        entityId: userId,
        action: 'UPDATE',
        details: {
          updatedUser: updatedUser.email,
          changes: body,
          updatedBy: session.user.email
        }
      }
    });

    return NextResponse.json({ user: updatedUser });
  } catch (error) {
    console.error('Error updating user:', error);
    return NextResponse.json({ error: 'Erreur lors de la modification de l\'utilisateur' }, { status: 500 });
  }
}